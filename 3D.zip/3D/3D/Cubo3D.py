import pygame
import sys
import math
from pygame.locals import *

class Cubo3D:
    def __init__(self, pos, size, color):
        self.pos = pos
        self.size = size
        self.color = color

        # Coordenadas de los vértices del cubo
        self.vertices = [
            [0, 0, 0],
            [0, 1, 0],
            [1, 1, 0],
            [1, 0, 0],
            [0, 0, 1],
            [0, 1, 1],
            [1, 1, 1],
            [1, 0, 1]
        ]

        # Caras del cubo, definidas por los índices de sus vértices
        self.caras = [
            [0, 1, 2, 3],
            [4, 5, 6, 7],
            [0, 1, 5, 4],
            [2, 3, 7, 6],
            [0, 3, 7, 4],
            [1, 2, 6, 5]
        ]

        self.rotating = True
        self.rotation_angle = 0

    def rotate(self, angle_x, angle_y, angle_z):
        if self.rotating:
            for i, vertex in enumerate(self.vertices):
                # Rotación en el eje X
                y = vertex[1] * math.cos(angle_x) - vertex[2] * math.sin(angle_x)
                z = vertex[1] * math.sin(angle_x) + vertex[2] * math.cos(angle_x)
                self.vertices[i][1] = y
                self.vertices[i][2] = z

                # Rotación en el eje Y
                x = vertex[0] * math.cos(angle_y) + vertex[2] * math.sin(angle_y)
                z = -vertex[0] * math.sin(angle_y) + vertex[2] * math.cos(angle_y)
                self.vertices[i][0] = x
                self.vertices[i][2] = z

                # Rotación en el eje Z
                x = vertex[0] * math.cos(angle_z) - vertex[1] * math.sin(angle_z)
                y = vertex[0] * math.sin(angle_z) + vertex[1] * math.cos(angle_z)
                self.vertices[i][0] = x
                self.vertices[i][1] = y

    def draw(self, pantalla):
        for cara in self.caras:
            puntos = []
            for v in cara:
                punto = self.vertices[v]
                punto = [punto[0] * self.size + self.pos[0], punto[1] * self.size + self.pos[1]]
                puntos.append(punto)
            pygame.draw.polygon(pantalla, self.color, puntos, 0)

def main():
    pygame.init()
    pantalla = pygame.display.set_mode((800, 600))
    pygame.display.set_caption('Cubo 3D')

    azul_morado_amarillo = [(0, 0, 255), (128, 0, 128), (255, 255, 0)]
    rosado_verde_gris = [(255, 105, 180), (0, 128, 0), (128, 128, 128)]
    color_index = 0  # Índice para seleccionar el color de la lista actual

    cubo = Cubo3D((400, 300), 100, azul_morado_amarillo[color_index])
    reloj = pygame.time.Clock()

    rotating = True
    rotate_with_mouse = False
    clicked_to_rotate = False
    zoom_factor = 1.0

    while True:
        pantalla.fill((0, 0, 0))

        for evento in pygame.event.get():
            if evento.type == QUIT:
                pygame.quit()
                sys.exit()
            elif evento.type == MOUSEBUTTONDOWN and evento.button == 3:  # Botón derecho del mouse
                color_index = (color_index + 1) % len(rosado_verde_gris)  # Cambia al siguiente color de la lista
                cubo.color = rosado_verde_gris[color_index]
            elif evento.type == KEYDOWN:
                if evento.key == K_ESCAPE:
                    color_index = (color_index + 1) % len(azul_morado_amarillo)  # Cambia al siguiente color de la lista
                    cubo.color = azul_morado_amarillo[color_index]
                elif evento.key == K_SPACE:
                    zoom_factor *= 1.1  # Aumenta el zoom en un 10%
                elif evento.key == K_RETURN:
                    zoom_factor /= 1.1  # Disminuye el zoom en un 10%

        for evento in pygame.event.get():
            if evento.type == QUIT:
                pygame.quit()
                sys.exit()
            elif evento.type == MOUSEBUTTONDOWN and evento.button == 1:
                mouse_pos = pygame.mouse.get_pos()
                if cubo.is_clicked(mouse_pos):
                    if clicked_to_rotate:
                        rotating = True
                        rotate_with_mouse = False
                        clicked_to_rotate = False
                        pygame.mouse.get_rel()  # Reinicia la posición del mouse
                    else:
                        rotate_with_mouse = True
                        rotating = False
                        clicked_to_rotate = True
                        pygame.mouse.get_rel()  # Captura la posición del mouse para calcular la rotación
            elif evento.type == MOUSEBUTTONUP and evento.button == 1:
                rotate_with_mouse = False
                rotating = True
                pygame.mouse.get_rel()  # Reinicia la posición del mouse
            elif evento.type == MOUSEMOTION and rotate_with_mouse:
                rel_x, _ = pygame.mouse.get_rel()
                cubo.rotation_angle += rel_x / 100  # Ajusta la velocidad de rotación
                cubo.rotate(0, cubo.rotation_angle, 0)

        if rotating:
            # Rotación del cubo
            angulo_x = pygame.time.get_ticks() / 1000.0
            angulo_y = pygame.time.get_ticks() / 1000.0
            angulo_z = pygame.time.get_ticks() / 1000.0
            cubo.rotate(angulo_x, angulo_y, angulo_z)

        cubo.size = int(100 * zoom_factor)  # Ajusta el tamaño del cubo según el factor de zoom

        cubo.draw(pantalla)

        pygame.display.flip()
        reloj.tick(60)

if __name__ == '__main__':
    main()








