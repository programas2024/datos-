import tkinter as tk
from tkinter import messagebox
from Cuenta import Cuenta

class Transaccion:
    def __init__(self, numero_transaccion, cuenta, monto):
        self._numero_transaccion = numero_transaccion
        self._cuenta = cuenta
        self._monto = monto

    def get_numero_transaccion(self):
        return self._numero_transaccion

    def get_cuenta(self):
        return self._cuenta

    def get_monto(self):
        return self._monto

    def realizar_transaccion(self):
        if self._monto > 0 and self._cuenta.get_saldo() >= self._monto:
            self._cuenta.set_saldo(self._cuenta.get_saldo() - self._monto)
            messagebox.showinfo("Resultado Transacción", f"Transacción exitosa. Nuevo saldo: {self._cuenta.get_saldo()}")
        else:
            messagebox.showerror("Resultado Transacción", "Error en la transacción. Verifique el monto o saldo insuficiente.")

    def __str__(self):
        return f"Número de Transacción: {self._numero_transaccion}\nCuenta: {self._cuenta.get_numero_cuenta()}\nMonto: {self._monto}"

# Ejemplo de uso
cuenta1 = Cuenta("123456789", 1000.0, "987654321")
transaccion1 = Transaccion("T123", cuenta1, 200.0)

# Realizar la transacción
transaccion1.realizar_transaccion()

