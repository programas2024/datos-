from Deposito import Deposito

class Cuenta:
    def __init__(self, numero_cuenta, saldo, cedula_cliente):
        self._numero_cuenta = numero_cuenta
        self._saldo = saldo
        self._cedula_cliente = cedula_cliente

    def get_numero_cuenta(self):
        return self._numero_cuenta

    def get_saldo(self):
        return self._saldo

    def set_saldo(self, saldo):
        self._saldo = saldo

    def depositar(self, monto):
        self._saldo += monto

# Ejemplo de uso
cuenta_manager = [Cuenta("123456789", 1000.0, "987654321")]

# Crear una instancia de la clase Deposito
deposito1 = Deposito("D001", cuenta_manager, 200.0)

# Realizar el depósito
resultado_deposito = deposito1.realizar_deposito()
