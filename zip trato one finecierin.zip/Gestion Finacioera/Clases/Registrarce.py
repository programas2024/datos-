import tkinter as tk
from tkinter import messagebox
from datetime import datetime
from Regitro import Regitro

class Registrarce:
    def __init__(self, master):
        self.master = master
        self.master.title("Interfaz de Registro")
        self.master.geometry("400x500")

        self.register_label = tk.Label(master, text="REGISTRARSE")

        self.cedula_label = tk.Label(master, text="Cédula:")
        self.cedula_entry = tk.Entry(master)

        self.nombre_label = tk.Label(master, text="Nombre:")
        self.nombre_entry = tk.Entry(master)

        self.apellidos_label = tk.Label(master, text="Apellidos:")
        self.apellidos_entry = tk.Entry(master)

        self.pais_label = tk.Label(master, text="País:")
        self.pais_entry = tk.Entry(master)

        self.ciudad_label = tk.Label(master, text="Ciudad:")
        self.ciudad_entry = tk.Entry(master)

        self.correo_label = tk.Label(master, text="Correo:")
        self.correo_entry = tk.Entry(master)

        self.usuario_label = tk.Label(master, text="Usuario:")
        self.usuario_entry = tk.Entry(master)

        self.contrasena_label = tk.Label(master, text="Contraseña:")
        self.contrasena_entry = tk.Entry(master, show="*")

        self.registrar_button = tk.Button(master, text="Registrar", command=self.registrar)
        self.cancelar_button = tk.Button(master, text="Cancelar", command=self.cancelar)

        # Instanciar la clase ManejoErroresRegistro
        self.errores_registro_handler = Regitro(self)

        # Posicionamiento en la ventana

        self.register_label.place(x=60, y=40)

        self.cedula_label.place(x=60, y=70)
        self.cedula_entry.place(x=120, y=70)

        self.nombre_label.place(x=60, y=100)
        self.nombre_entry.place(x=120, y=100)

        self.apellidos_label.place(x=60, y=130)
        self.apellidos_entry.place(x=120, y=130)

        self.pais_label.place(x=60, y=160)
        self.pais_entry.place(x=120, y=160)

        self.ciudad_label.place(x=60, y=190)
        self.ciudad_entry.place(x=120, y=190)

        self.correo_label.place(x=60, y=220)
        self.correo_entry.place(x=120, y=220)

        self.usuario_label.place(x=60, y=250)
        self.usuario_entry.place(x=120, y=250)

        self.contrasena_label.place(x=60, y=280)
        self.contrasena_entry.place(x=130, y=280)

        self.registrar_button.place(x=60, y=320, width=90)
        self.cancelar_button.place(x=190, y=320, width=90)

    def registrar(self):
        cedula = self.cedula_entry.get()
        nombre = self.nombre_entry.get()
        apellidos = self.apellidos_entry.get()
        pais = self.pais_entry.get()
        ciudad = self.ciudad_entry.get()
        correo = self.correo_entry.get()
        usuario = self.usuario_entry.get()
        contrasena = self.contrasena_entry.get()

        if not cedula.isnumeric():
           
            self.errores_registro_handler.limpiar_campos("Cédula")
        elif not nombre.isalpha():
           
            self.errores_registro_handler.limpiar_campos("Nombre")
        elif not apellidos.isalpha():
           
            self.errores_registro_handler.limpiar_campos("Apellidos")
        elif not pais.isalpha():
           
            self.errores_registro_handler.limpiar_campos("País")
        elif not ciudad.isalpha():
           
            self.errores_registro_handler.limpiar_campos("Ciudad")
        elif not "@" in correo or "." not in correo:
            
            self.errores_registro_handler.limpiar_campos("Correo")
        elif not usuario.isalnum():
           
            self.errores_registro_handler.limpiar_campos("Usuario")
        elif not contrasena:
            
            self.errores_registro_handler.limpiar_campos("Contraseña")
        else:
            ahora = datetime.now()
            fecha_registro = ahora.strftime("%Y-%m-%d %H:%M:%S")
            mensaje = f"Registro exitoso!\n\nDatos:\nCédula: {cedula}\nNombre: {nombre}\nApellidos: {apellidos}\nPaís: {pais}\nCiudad: {ciudad}\nCorreo: {correo}\nUsuario: {usuario}\nContraseña: {contrasena}\n\nFecha y hora de registro: {fecha_registro}"
            messagebox.showinfo("Registro Exitoso", mensaje)

           

    def cancelar(self):
        self.master.destroy()


