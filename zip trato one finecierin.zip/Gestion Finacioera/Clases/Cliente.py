import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import threading
import time

from Clientecitos import Clientesitos


class Cliente:
    def __init__(self, master):
        self.master = master
        self.master.title("Interfaz de Clientes")
        self.master.geometry("400x300")
        self.master.configure(bg="white")  # Cambia el color de fondo a azul


        #imagenes

        self.imagen_agregar = tk.PhotoImage(file="Imagenes\\agregar.gif")
        self.imagen_escoba = tk.PhotoImage(file="Imagenes\\escoba.gif")
        self.imagen_salir = tk.PhotoImage(file="Imagenes\\cerrar-sesion.gif")

        self.cedula_label = tk.Label(master,background="white", text="Cédula:")
        self.cedula_entry = tk.Entry(master)

        self.nombre_label = tk.Label(master,background="white", text="Nombre:")
        self.nombre_entry = tk.Entry(master)

        self.apellidos_label = tk.Label(master,background="white", text="Apellidos:")
        self.apellidos_entry = tk.Entry(master)

        self.telefono_label = tk.Label(master,background="white", text="Teléfono:")
        self.telefono_entry = tk.Entry(master)

        self.email_label = tk.Label(master,background="white", text="Email:")
        self.email_entry = tk.Entry(master)

        self.agregar_button = tk.Button(master,background="white", text="Agregar",image=self.imagen_agregar, command=self.agregar)
        self.limpiar_button = tk.Button(master,background="white", text="Limpiar",image=self.imagen_escoba, command=self.limpiar)
        self.salir_button = tk.Button(master, text="Salir",background="white",image=self.imagen_salir, command=self.salir)

        # Posicionamiento en la ventana
        self.cedula_label.place(x=60, y=20)
        self.cedula_entry.place(x=120, y=20)

        self.nombre_label.place(x=60, y=50)
        self.nombre_entry.place(x=120, y=50)

        self.apellidos_label.place(x=60, y=80)
        self.apellidos_entry.place(x=120, y=80)

        self.telefono_label.place(x=60, y=110)
        self.telefono_entry.place(x=120, y=110)

        self.email_label.place(x=60, y=140)
        self.email_entry.place(x=120, y=140)

        self.agregar_button.place(x=60, y=180, width=90)
        self.limpiar_button.place(x=170, y=180, width=90)
        self.salir_button.place(x=280, y=180, width=90)

        # Crear la instancia de Clientesitos y pasarla a Cliente
        self.clientesitos_instance = Clientesitos(self)

    def agregar(self):
        if self.verificar_condiciones():
            ahora = datetime.now()
            fecha_registro = ahora.strftime("%Y-%m-%d %H:%M:%S")
            mensaje = f"Registro exitoso!\n\nDatos:\nCédula: {self.cedula_entry.get()}\nNombre: {self.nombre_entry.get()}\nApellidos: {self.apellidos_entry.get()}\nTeléfono: {self.telefono_entry.get()}\nEmail: {self.email_entry.get()}\n\nFecha y hora de registro: {fecha_registro}"
            messagebox.showinfo("Registro Exitoso", mensaje)
            self.clientesitos_instance.limpiar_campos()

    def limpiar(self):
        self.cedula_entry.delete(0, tk.END)
        self.nombre_entry.delete(0, tk.END)
        self.apellidos_entry.delete(0, tk.END)
        self.telefono_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)

    def salir(self):
        self.master.destroy()

    def verificar_condiciones(self):
        
        cedula = self.cedula_entry.get()
        if not cedula.isdigit():
            return False

        # Verificar si el teléfono es numérico
        telefono = self.telefono_entry.get()
        if not telefono.isdigit():
            return False

        # Verificar si el nombre y apellidos son alfabéticos
        nombre = self.nombre_entry.get()
        apellidos = self.apellidos_entry.get()
        if not nombre.isalpha() or not apellidos.isalpha():
            return False

        # Verificar si el email contiene @
        email = self.email_entry.get()
        if "@" not in email:
            return False

        return True

    def cambiar_color_cedula(self):
        input_text = self.cedula_entry.get()
        if input_text.isdigit():
            if len(input_text) == 1:
                self.cedula_entry.config(bg="white")
            elif len(input_text) >= 2:
                self.cedula_entry.config(bg="yellow")
            else:
                self.cedula_entry.config(bg="white")
        else:
            self.cedula_entry.config(bg="white")

    def cambiar_color_nombre(self):
        input_text = self.nombre_entry.get()
        if input_text.isalpha():
            if len(input_text) == 1:
                self.nombre_entry.config(bg="white")
            elif len(input_text) >= 2:
                self.nombre_entry.config(bg="yellow")
            else:
                self.nombre_entry.config(bg="white")
        else:
            self.nombre_entry.config(bg="white")

    def cambiar_color_apellidos(self):
        input_text = self.apellidos_entry.get()
        if input_text.isalpha():
            if len(input_text) == 1:
                self.apellidos_entry.config(bg="white")
            elif len(input_text) >= 2:
                self.apellidos_entry.config(bg="yellow")
            else:
                self.apellidos_entry.config(bg="white")
        else:
            self.apellidos_entry.config(bg="white")

    def cambiar_color_telefono(self):
        input_text = self.telefono_entry.get()
        if input_text.isdigit():
            if len(input_text) == 1:
                self.telefono_entry.config(bg="white")
            elif len(input_text) >= 2:
                self.telefono_entry.config(bg="yellow")
            else:
                self.telefono_entry.config(bg="white")
        else:
            self.telefono_entry.config(bg="white")

    def cambiar_color_correo(self):
        input_text = self.email_entry.get()
        if "@" not in input_text:
            if len(input_text) == 1:
                self.email_entry.config(bg="white")
            elif len(input_text) >= 2:
                self.email_entry.config(bg="yellow")
            else:
                self.email_entry.config(bg="white")
        else:
            self.email_entry.config(bg="white")
