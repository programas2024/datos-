import tkinter as tk
from tkinter.colorchooser import askcolor
from tkinter import filedialog
from PIL import ImageGrab
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from Herramientas import DibujosPrimitivos
from Tooltip import Tooltip

class CaraFeliz:
    def __init__(self, master):
        self.master = master
        self.master.configure(bg="white")
        self.canvas = tk.Canvas(master, width=400, height=400, bg='white')
        self.canvas.pack()

        self.imagen_derecha = tk.PhotoImage(file="imagenes\\flechadere.png")
        self.imagen_izquierda = tk.PhotoImage(file="imagenes\\flechaizquierda.png")
        self.imagen_paleta = tk.PhotoImage(file="imagenes\\paleta.png")
        self.imagen_crear = tk.PhotoImage(file="imagenes\\configuracion .png")
        self.imagen_salir = tk.PhotoImage(file="imagenes\\borrar.png")
        self.imagen_guardar = tk.PhotoImage(file="imagenes\\guardar.png")

        # Definir colores iniciales
        self.color_cara = 'black'
        self.color_ojos = 'green'
        self.color_nariz = 'green'
        self.color_boca = 'purple'

        # Dibujar la cara feliz inicialmente
        self.dibujar_cara_feliz()

        # Agregar botones para desplazar la cara, cambiar su estado, cambiar color y salir
        self.boton_izquierda = tk.Button(master, image=self.imagen_izquierda, background="white", command=self.desplazar_izquierda)
        self.boton_izquierda_window = self.canvas.create_window(40, 10, anchor=tk.NW, window=self.boton_izquierda)
        Tooltip(self.boton_izquierda,"Estado feliz")

        self.boton_derecha = tk.Button(master, image=self.imagen_derecha, background="white", command=self.desplazar_derecha)
        self.boton_derecha_window = self.canvas.create_window(80, 10, anchor=tk.NW, window=self.boton_derecha)
        Tooltip(self.boton_derecha,"Estado triste ")

        self.boton_color = tk.Button(master, image=self.imagen_paleta, background="white", command=self.cambiar_color_cara)
        self.boton_color_window = self.canvas.create_window(120, 10, anchor=tk.NW, window=self.boton_color)
        Tooltip(self.boton_color,"Cambiar color cara ")

        self.boton_crear = tk.Button(master, image=self.imagen_crear, background="white", command=self.crear)
        self.boton_crear_window = self.canvas.create_window(160, 10, anchor=tk.NW, window=self.boton_crear)
        Tooltip(self.boton_crear,"(beta) crear con figuras ")

        self.boton_guardar = tk.Button(master, image=self.imagen_guardar, background="white", command=self.guardar_imagen)
        self.boton_guardar_window = self.canvas.create_window(200, 10, anchor=tk.NW, window=self.boton_guardar)
        Tooltip(self.boton_guardar,"Guardar lienzo ")

        self.boton_salir = tk.Button(master, image=self.imagen_salir, background="white", command=self.salir)
        self.boton_salir_window = self.canvas.create_window(240, 10, anchor=tk.NW, window=self.boton_salir)
        Tooltip(self.boton_salir,"Cerrar aplicacion ")

        self.estado_feliz = True  # Inicialmente feliz
        
        

        # Atajos de teclado
        master.bind('<Left>', lambda event: self.desplazar_izquierda())
        master.bind('<Right>', lambda event: self.desplazar_derecha())

    def dibujar_cara_feliz(self):
        # Dibujar la cara feliz
        self.canvas.delete("cara")  # Borra la cara anterior si existe
        cara = self.canvas.create_oval(50, 50, 350, 350, outline='black', width=2, fill=self.color_cara, tags="cara")
        
        # Dibujar la boca feliz
        boca = self.canvas.create_arc(120, 250, 280, 320, start=30, extent=120, style=tk.ARC, outline='green', width=2, fill=self.color_boca, tags="cara")
        
        # Dibujar los ojos
        ojo_izquierdo = self.canvas.create_oval(120, 120, 180, 180, outline='black', width=2, fill=self.color_ojos, tags="cara")
        ojo_derecho = self.canvas.create_oval(220, 120, 280, 180, outline='black', width=2, fill=self.color_ojos, tags="cara")
        
        # Dibujar la nariz
        nariz = self.canvas.create_line(200, 180, 200, 240, width=5, fill=self.color_nariz, tags="cara")

    def dibujar_cara_triste(self):
        # Dibujar la cara triste
        self.canvas.delete("cara")  # Borra la cara anterior si existe
        cara = self.canvas.create_oval(50, 50, 350, 350, outline='black', width=2, fill=self.color_cara, tags="cara")
        
        # Dibujar la boca triste
        boca = self.canvas.create_arc(120, 250, 280, 320, start=210, extent=120, style=tk.ARC, outline='green', width=2, fill=self.color_boca, tags="cara")
        
        # Dibujar los ojos
        ojo_izquierdo = self.canvas.create_oval(120, 120, 180, 180, outline='black', width=2, fill=self.color_ojos, tags="cara")
        ojo_derecho = self.canvas.create_oval(220, 120, 280, 180, outline='black', width=2, fill=self.color_ojos, tags="cara")
        
        # Dibujar la nariz
        nariz = self.canvas.create_line(200, 180, 200, 240, width=5, fill=self.color_nariz, tags="cara")

    def desplazar_izquierda(self, event=None):
        if self.canvas.coords("cara")[0] > 10:  # Evita que la cara salga del lienzo
            self.canvas.move("cara", -10, 0)
            self.estado_feliz = False  # Cambiar al estado triste
            self.dibujar_cara_triste()

    def desplazar_derecha(self, event=None):
        if self.canvas.coords("cara")[2] < 390:  # Evita que la cara salga del lienzo
            self.canvas.move("cara", 10, 0)
            self.estado_feliz = True  # Cambiar al estado feliz
            self.dibujar_cara_feliz()

    def cambiar_color_cara(self):
        color = askcolor(title="Elige un color para la cara")
        if color[1]:  # Si se selecciona un color
            self.color_cara = color[1]
            self.canvas.itemconfig("cara", fill=self.color_cara)

    def guardar_imagen(self):
        # Obtener la ubicación del archivo para guardar
        filename = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("Word files", "*.docx"), ("PDF files", "*.pdf")])
        if filename:
            # Capturar la imagen del lienzo
            x = self.master.winfo_rootx() + self.canvas.winfo_x()
            y = self.master.winfo_rooty() + self.canvas.winfo_y()
            x1 = x + self.canvas.winfo_width()
            y1 = y + self.canvas.winfo_height()
            ImageGrab.grab().crop((x, y, x1, y1)).save(filename)

    def crear(self):
        # Ocultar el botón
        self.boton_crear.config(state=tk.DISABLED)
        # Crear la ventana de DibujosPrimitivos
        self.dibujos = DibujosPrimitivos(self.master)
        # Después de cerrar la ventana, volver a habilitar el botón
        self.master.after(100, self.habilitar_boton)

    def habilitar_boton(self):
        self.boton_crear.config(state=tk.NORMAL)

    def salir(self):
        self.master.quit()













