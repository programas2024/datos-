import tkinter as tk

class DibujosPrimitivos:
    def __init__(self, master):
        self.master = master
        
        # Canvas para los dibujos
        self.canvas = tk.Canvas(master, width=400, height=600, bg='white')
        self.canvas.pack()

        # Diccionario para mantener las referencias de los dibujos
        self.dibujos = {}

        # Crear triángulo
        self.dibujos['triangulo'] = self.crear_dibujo('triangulo', [(300, 100), (350, 200), (250, 200)], fill='red', outline='black')

        # Crear cuadrado
        self.dibujos['cuadrado'] = self.crear_dibujo('cuadrado', [(300, 250), (400, 250), (400, 350), (300, 350)], fill='blue', outline='black')

        # Crear rectángulo
        self.dibujos['rectangulo'] = self.crear_dibujo('rectangulo', [(300, 400), (400, 400), (400, 500), (300, 500)], fill='green', outline='black')

        # Crear círculo
        self.dibujos['circulo'] = self.crear_dibujo('circulo', [(350, 600)], 50, fill='orange', outline='black')

        # Crear hexágono
        self.dibujos['hexagono'] = self.crear_dibujo('hexagono', [(150, 150), (200, 100), (250, 150), (250, 200), (200, 250), (150, 200)], fill='yellow', outline='black')

        # Crear círculos pequeños
        self.dibujos['circulo_peq_1'] = self.crear_dibujo('circulo_peq_1', [(200, 250)], 10, fill='purple', outline='black')
        self.dibujos['circulo_peq_2'] = self.crear_dibujo('circulo_peq_2', [(200, 300)], 10, fill='purple', outline='black')
        self.dibujos['circulo_peq_3'] = self.crear_dibujo('circulo_peq_3', [(200, 350)], 10, fill='purple', outline='black')

        # Crear óvalo
        self.dibujos['ovalo'] = self.crear_dibujo('ovalo', [(150, 400), (250, 450)], fill='cyan', outline='black')

        # Crear más figuras
        # Puedes agregar más figuras siguiendo el mismo patrón

        # Crear figura 1
        self.dibujos['figura_1'] = self.crear_dibujo('figura_1', [(50, 50), (100, 100), (50, 100)], fill='pink', outline='black')

        # Crear figura 2
        self.dibujos['figura_2'] = self.crear_dibujo('figura_2', [(200, 200), (250, 250), (200, 250)], fill='brown', outline='black')

        # Crear figura 3
        self.dibujos['figura_3'] = self.crear_dibujo('figura_3', [(300, 300), (350, 350), (300, 350)], fill='magenta', outline='black')

        # Crear figura 4
        self.dibujos['figura_4'] = self.crear_dibujo('figura_4', [(400, 400), (450, 450), (400, 450)], fill='gray', outline='black')

        # Variables para almacenar la posición del arrastre
        self.offset_x = 0
        self.offset_y = 0
        self.dibujo_seleccionado = None

        # Enlazar eventos de arrastre en el canvas
        self.canvas.bind("<ButtonPress-1>", self.iniciar_arrastre)
        self.canvas.bind("<B1-Motion>", self.mover_arrastre)
        self.canvas.bind("<ButtonRelease-1>", self.soltar_arrastre)

    def crear_dibujo(self, nombre, puntos, *args, **kwargs):
        # Crea un nuevo dibujo en el lienzo
        if nombre in ['triangulo', 'hexagono']:
            return self.canvas.create_polygon(puntos, *args, **kwargs)
        elif nombre in ['cuadrado', 'rectangulo']:
            return self.canvas.create_polygon(puntos[0][0], puntos[0][1], puntos[1][0], puntos[0][1], puntos[1][0], puntos[1][1], puntos[0][0], puntos[1][1], *args, **kwargs)
        elif nombre == 'circulo':
            return self.canvas.create_oval(puntos[0][0]-args[0], puntos[0][1]-args[0], puntos[0][0]+args[0], puntos[0][1]+args[0], *args[1:], **kwargs)
        elif nombre.startswith('circulo_peq'):
            return self.canvas.create_oval(puntos[0][0]-args[0], puntos[0][1]-args[0], puntos[0][0]+args[0], puntos[0][1]+args[0], *args[1:], **kwargs)
        elif nombre == 'ovalo':
            return self.canvas.create_oval(puntos, *args, **kwargs)

    def iniciar_arrastre(self, evento):
        # Inicia el arrastre de un dibujo cuando se presiona el botón del ratón
        self.offset_x = evento.x
        self.offset_y = evento.y
        self.dibujo_seleccionado = self.canvas.find_closest(evento.x, evento.y)[0]

    def mover_arrastre(self, evento):
        # Mueve el dibujo seleccionado mientras se arrastra el ratón
        if self.dibujo_seleccionado:
            x = evento.x - self.offset_x
            y = evento.y - self.offset_y
            self.canvas.move(self.dibujo_seleccionado, x, y)
            self.offset_x = evento.x
            self.offset_y = evento.y

    def soltar_arrastre(self, evento):
        # Libera el arrastre del dibujo cuando se suelta el botón del ratón
        self.dibujo_seleccionado = None
        

    def mostrar_ventana(self):
        # Muestra la ventana de DibujosPrimitivos
        dibujo_window = tk.Toplevel(self.master)
        dibujo_window.title("Dibujos Primitivos")
        dibujo_window.geometry("600x600")
        dibujos = DibujosPrimitivos(dibujo_window)

    def cerrar_ventana(self):
        # Cierra la ventana actual
        self.master.destroy()






