import tkinter as tk
from Canvas import CaraFeliz

class Main():
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Cara Feliz")
        self.app = CaraFeliz(self.root)

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    main = Main()
    main.run()