

from Formulario import Formulario

class Main():
    def main():
        app=Formulario()
    main()