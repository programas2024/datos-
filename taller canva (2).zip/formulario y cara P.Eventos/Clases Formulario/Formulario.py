import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from Verificacion import Verificacion
from Cara.Tooltip import Tooltip
from Ayuda import Ayuda

class Formulario:
    def __init__(self, master):
        self.master = master
        self.master.title("Formulario")
        self.master.geometry("550x630")
        self.master.configure(bg="white")  # Fondo blanco para la ventana

        self.imagen_carro = tk.PhotoImage(file="imagenes\\carro.png")
        self.imagen_limpio = tk.PhotoImage(file="imagenes\\codigo-limpio (1).png")
        self.imagen_curri = tk.PhotoImage(file="imagenes\\curriculum.png")
        self.imagen_masculino = tk.PhotoImage(file="imagenes\\masculino .png")
        self.imagen_mujer = tk.PhotoImage(file="imagenes\\mujer.png")
        self.imagen_otro = tk.PhotoImage(file="imagenes\\otro-genero.png")
        self.imagen_licencia = tk.PhotoImage(file="imagenes\\licencia.png")
        self.imagen_perfil = tk.PhotoImage(file="imagenes\\perfil.png")
        self.imagen_cancelar = tk.PhotoImage(file="imagenes\\cancelar .png")
        self.imagen_ayuda = tk.PhotoImage(file="imagenes\\ayudar2.png")


        self.verificacion = Verificacion()

        self.titulo = tk.Label(master, text="AGREGAR EMPLEADO", font=("Arial", 18), bg="white")  # Fondo blanco para el título
        self.titulo.place(x=225, y=30, anchor=tk.CENTER)

        self.nombre_label = tk.Label(master, text="Ingrese su nombre:", bg="white")  # Fondo blanco para la etiqueta de nombre
        self.nombre_label.place(x=50, y=100)
        self.nombre_entry = tk.Entry(master)
        self.nombre_entry.insert(0, "Digite su nombre")
        self.nombre_entry.bind("<FocusIn>", self.clear_placeholder)
        self.nombre_entry.bind("<FocusOut>", self.restore_placeholder)
        self.nombre_entry.bind("<KeyRelease>", self.validar_nombre)  # Agregamos un evento para validar el contenido
        self.nombre_entry.place(x=200, y=100)
        Tooltip(self.nombre_entry,"Digite el nombre")


        self.apellido_label = tk.Label(master, text="Ingrese su apellido:", bg="white")  # Fondo blanco para la etiqueta de apellido
        self.apellido_label.place(x=50, y=150)
        self.apellido_entry = tk.Entry(master)
        self.apellido_entry.insert(0, "Digite su apellido")
        self.apellido_entry.bind("<FocusIn>", self.clear_placeholder)
        self.apellido_entry.bind("<FocusOut>", self.restore_placeholder)
        self.apellido_entry.bind("<KeyRelease>", self.validar_apellido)  # Agregamos un evento para validar el contenido
        self.apellido_entry.place(x=200, y=150)
        Tooltip(self.apellido_entry,"Digite el apellido")


        self.correo_label = tk.Label(master, text="Ingrese su correo:", bg="white")  # Fondo blanco para la etiqueta de correo
        self.correo_label.place(x=50, y=200)
        self.correo_entry = tk.Entry(master)
        self.correo_entry.insert(0, "Digite su correo")
        self.correo_entry.bind("<FocusIn>", self.clear_placeholder)
        self.correo_entry.bind("<FocusOut>", self.restore_placeholder)
        self.correo_entry.place(x=200, y=200)
        Tooltip(self.correo_entry,"Digite el correo")


        self.genero_label = tk.Label(master, text="Género:", bg="white")  # Fondo blanco para la etiqueta de género
        self.genero_label.place(x=50, y=250)

        self.genero_var = tk.StringVar()
        self.genero_var.set("Mujer")  # Por defecto seleccionado Mujer
        self.mujer_radio = tk.Radiobutton(master, text="Mujer",image=self.imagen_mujer, variable=self.genero_var, value="Mujer", bg="white")  # Fondo blanco para los radio buttons
        self.mujer_radio.place(x=200, y=250)
        Tooltip(self.mujer_radio,"Mujer")

        self.hombre_radio = tk.Radiobutton(master, text="Hombre",image=self.imagen_masculino, variable=self.genero_var, value="Hombre", bg="white")
        self.hombre_radio.place(x=300, y=250)
        Tooltip(self.hombre_radio,"Hombre")

        self.otro_radio = tk.Radiobutton(master, text="Otro",image=self.imagen_otro, variable=self.genero_var, value="Otro", bg="white")
        self.otro_radio.place(x=400, y=250)
        Tooltip(self.otro_radio,"Otro")


        self.vehiculo_var = tk.IntVar()

        self.tiene_vehiculo_label = tk.Label(master, text="Tiene vehículo:", bg="white")  # Fondo blanco para la etiqueta de tiene vehículo
        self.tiene_vehiculo_label.place(x=50, y=315)
        self.tiene_vehiculo_label = tk.Label(master, text="Tiene vehículo:",image=self.imagen_carro, bg="white")  # Fondo blanco para la etiqueta de tiene vehículo
        self.tiene_vehiculo_label.place(x=170, y=310)
        self.vehiculo_check = tk.Checkbutton(master, variable=self.vehiculo_var)
        self.vehiculo_check.place(x=230, y=315)

        self.licencia_label = tk.Label(master, text="Tipo de Licencia:", bg="white")  # Fondo blanco para la etiqueta de tipo de licencia
        self.licencia_label.place(x=50, y=350)

        self.licencia_label = tk.Label(master, text="Tipo de Licencia:",image=self.imagen_licencia, bg="white")  # Fondo blanco para la etiqueta de tipo de licencia
        self.licencia_label.place(x=150, y=345)

        self.licencia_combobox = ttk.Combobox(master, values=["A1", "A2", "B1", "B2", "C1", "C2"])
        self.licencia_combobox.place(x=200, y=350)

        self.perfil_frame = tk.Frame(master, width=400, height=150, bd=2, relief=tk.SOLID, bg="white")  # Fondo blanco para el frame
        self.perfil_frame.place(x=75, y=400)

        self.perfil_label = tk.Label(self.perfil_frame, text="Perfil:", bg="white")  # Fondo blanco para la etiqueta de perfil
        self.perfil_label.place(x=5, y=5)

        self.perfil_label = tk.Label(self.perfil_frame, text="Perfil:",image=self.imagen_perfil, bg="white")  # Fondo blanco para la etiqueta de perfil
        self.perfil_label.place(x=50, y=4)

        self.perfil_text = tk.Text(self.perfil_frame, wrap=tk.WORD, width=50, height=6)
        self.perfil_text.insert(tk.END, "Describa su perfil")
        self.perfil_text.bind("<FocusIn>", self.clear_placeholder2)
        self.perfil_text.bind("<FocusOut>", self.restore_placeholder2)
        self.perfil_text.place(x=5, y=30)
        self.perfil_text.bind("<KeyRelease>", self.update_word_count) 
        Tooltip(self.perfil_label,"Digite el perfil")


        self.scrollbar = ttk.Scrollbar(self.perfil_frame, orient=tk.VERTICAL, command=self.perfil_text.yview)
        self.scrollbar.place(relx=1, rely=0, relheight=1, anchor=tk.NE)
        self.perfil_text.config(yscrollcommand=self.scrollbar.set)

        self.word_count_label = tk.Label(master, text="0/400 caracteres", bg="white")  # Fondo blanco para el contador de palabras
        self.word_count_label.place(x=75, y=550)

        self.aceptar_button = tk.Button(master, text="Aceptar", image=self.imagen_curri,background="white",command=self.verificar_y_mostrar_info)
        self.aceptar_button.place(x=150, y=570,width=90,height=40)
        Tooltip(self.aceptar_button,"Aceptar")


        self.limpiar_button = tk.Button(master, text="Limpiar",image=self.imagen_limpio,background="white", command=self.limpiar_campos)
        self.limpiar_button.place(x=250, y=570,width=90,height=40)
        Tooltip(self.limpiar_button,"Limpiar campos")


        self.Salir_button = tk.Button(master, text="salir",image=self.imagen_cancelar,background="white", command=self.salir)
        self.Salir_button.place(x=350, y=570,width=90,height=40)
        Tooltip(self.Salir_button,"Salir")

        self.Ayuda_button = tk.Button(master, text="Ayuda",image=self.imagen_ayuda,background="white", command=self.ayuda)
        self.Ayuda_button.place(x=400, y=100,width=90,height=40)
        Tooltip(self.Ayuda_button,"Ayuda")


    def ayuda(self):
        ayuda = Ayuda(master)
        ayuda.mostrar()

        
    def salir(self):
        # Lógica para el botón de salir
        self.master.destroy()

    def clear_placeholder(self, event):
        widget = event.widget
        if widget.get() == "Digite su nombre" or widget.get() == "Digite su apellido" or widget.get() == "Digite su correo":
            widget.delete(0, tk.END)

    def restore_placeholder(self, event):
        widget = event.widget
        if not widget.get():
            if widget == self.nombre_entry:
                widget.insert(0, "Digite su nombre")
            elif widget == self.apellido_entry:
                widget.insert(0, "Digite su apellido")
            elif widget == self.correo_entry:
                widget.insert(0, "Digite su correo")

    def clear_placeholder2(self, event):
        widget = event.widget
        if widget.get("1.0", tk.END).strip() == "Describa su perfil":
            widget.delete("1.0", tk.END) # Borra todo el contenido del widget

    def restore_placeholder2(self, event):
        widget = event.widget
        if not widget.get("1.0", tk.END).strip():
            if widget == self.perfil_text:
                widget.insert(tk.END, "Describa su perfil")

    def update_word_count(self, event=None):  # Modificamos el método para aceptar un argumento de evento opcional
        profile_text = self.perfil_text.get("1.0", tk.END)
        char_count = len(profile_text) - 1  # Restar 1 para excluir el salto de línea al final
        self.word_count_label.config(text=f"{char_count}/400 caracteres")
        if char_count > 400:
            messagebox.showwarning("Límite de caracteres", "Ha alcanzado el límite de 400 caracteres.")
            self.perfil_text.delete("end-2c", tk.END)  # 
    def validar_campos_llenos(self):
        campos_faltantes = []

        if not self.nombre_entry.get():
            self.nombre_entry.config(bg="red")
            campos_faltantes.append("Nombre")
        else:
            self.nombre_entry.config(bg="white")

        if not self.apellido_entry.get():
            self.apellido_entry.config(bg="red")
            campos_faltantes.append("Apellido")
        else:
            self.apellido_entry.config(bg="white")

        if not self.correo_entry.get():
            self.correo_entry.config(bg="red")
            campos_faltantes.append("Correo")
        else:
            self.correo_entry.config(bg="white")

        if self.perfil_text.get("1.0", "end-1c").strip() == "Describa su perfil":
            self.perfil_text.config(bg="white")
            campos_faltantes.append("Perfil")
        else:
            self.perfil_text.config(bg="white")

        return campos_faltantes

    def verificar_y_mostrar_info(self):
        campos_faltantes = self.validar_campos_llenos()

        if not campos_faltantes:
            nombre = self.nombre_entry.get()
            apellido = self.apellido_entry.get()
            correo = self.correo_entry.get()
            genero = self.genero_var.get()
            licencia = self.licencia_combobox.get()
            perfil = self.perfil_text.get("1.0", "end-1c")  # Obtener texto del perfil

            mensaje = f"Nombre: {nombre}\nApellido: {apellido}\nCorreo: {correo}\nGénero: {genero}\nTipo de Licencia: {licencia}\nPerfil: {perfil}"
            messagebox.showinfo("Información del Formulario", mensaje)
        else:
            # Si hay campos faltantes, no hacer nada
            pass

    def limpiar_campos(self):
        self.nombre_entry.delete(0, tk.END)
        self.nombre_entry.insert(0, "Digite su nombre")
        self.apellido_entry.delete(0, tk.END)
        self.apellido_entry.insert(0, "Digite su apellido")
        self.correo_entry.delete(0, tk.END)
        self.correo_entry.insert(0, "Digite su correo")
        self.genero_var.set("Mujer")
        self.vehiculo_var.set(0)
        self.licencia_combobox.set("")
        self.perfil_text.delete("1.0", tk.END)
        self.perfil_text.insert(tk.END, "Describa su perfil")

    def validar_nombre(self, event):
        contenido = self.nombre_entry.get()
        if not Verificacion.es_letras(contenido):  # Utilizamos el método es_letras de la clase Verificacion
            self.nombre_entry.delete(len(contenido) - 1, tk.END)  # Eliminamos el último carácter si no es una letra
        else:
            self.nombre_entry.config(bg="white")  # Restauramos el color de fondo a blanco si el contenido es válido

    def validar_apellido(self, event):
        contenido = self.apellido_entry.get()
        if not Verificacion.es_letras(contenido):  # Utilizamos el método es_letras de la clase Verificacion
            self.apellido_entry.delete(len(contenido) - 1, tk.END)  # Eliminamos el último carácter si no es una letra
        else:
            self.apellido_entry.config(bg="white")


master = tk.Tk()
app = Formulario(master)
master.mainloop()



