import re

class Verificacion:
    @staticmethod
    def verificar_campos(nombre, apellido, correo, perfil):
        if not all((nombre, apellido, correo, perfil)):
            return False, [campo for campo, valor in [("Nombre", nombre), ("Apellido", apellido), ("Correo", correo), ("Perfil", perfil)] if not valor]
        if not (Verificacion.es_letras(nombre) and Verificacion.es_letras(apellido)):
            return False, ["Nombre", "Apellido"]
        return True, []

    @staticmethod
    def es_letras(texto):
        return bool(re.match("^[a-zA-ZÁÉÍÓÚáéíóúñÑüÜ\s]+$", texto))