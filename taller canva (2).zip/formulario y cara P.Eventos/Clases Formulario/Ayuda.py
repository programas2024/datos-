import tkinter as tk
from PIL import Image, ImageTk

import tkinter as tk
from PIL import Image, ImageTk

class Ayuda:
    def __init__(self, master):
        self.master = master
        self.ventana_ayuda = tk.Toplevel(master)
        self.ventana_ayuda.title("Ayuda")
        self.ventana_ayuda.geometry("800x800")
        self.ventana_ayuda.configure(bg="white")

        try:
            imagen_ayuda = Image.open("imagenes\\ayuda.png")
            imagen_ayuda = imagen_ayuda.resize((650, 650))
            self.imagen_ayuda = ImageTk.PhotoImage(imagen_ayuda)
            self.canvas = tk.Canvas(self.ventana_ayuda, width=800, height=800, bg="white")
            self.canvas.pack()
            self.canvas.create_image(0, 0, anchor=tk.NW, image=self.imagen_ayuda)
        except FileNotFoundError:
            print("No se pudo encontrar la imagen 'ayuda.png'")
        except Exception as e:
            print("Error al cargar la imagen:", e)

    def mostrar(self):
        self.ventana_ayuda.mainloop()










